
package library.ms;

/**
 *
 * @author Pial
 */
public class LibraryMS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
