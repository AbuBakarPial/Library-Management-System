
import java.sql.*;
import javax.swing.JOptionPane;

public class Connector {
   Connection conn;
   
   public static Connection ConnecrDb(){
       try{
          
          Class.forName("com.mysql.jdbc.Driver")  ;
          Connection conn=DriverManager.getConnection("jdbc.");
          return conn;
       }
       catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
           return null;
       }
   }
}
