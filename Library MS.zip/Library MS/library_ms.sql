-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2018 at 07:35 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_ms`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `UserName` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Sec_Ques` varchar(500) NOT NULL,
  `Answer` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`UserName`, `Name`, `Password`, `Sec_Ques`, `Answer`) VALUES
('Inam', 'Arif Inam', '123456', 'What is your mother tounge ?', 'Bangla'),
('Shubel Sunny', 'Sunny', 'Sunny', 'What is your mother tounge ?', 'Bangla');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Book_ID` int(50) NOT NULL,
  `BookName` varchar(100) NOT NULL,
  `Edition` varchar(100) NOT NULL,
  `Publisher` varchar(100) NOT NULL,
  `Price` varchar(10000) NOT NULL,
  `Pages` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `BookID` varchar(100) NOT NULL,
  `BookName` varchar(100) NOT NULL,
  `Edition` varchar(100) NOT NULL,
  `Publisher` varchar(100) NOT NULL,
  `Price` varchar(10000) NOT NULL,
  `Pages` varchar(10000) NOT NULL,
  `StudentId` varchar(100) NOT NULL,
  `SName` varchar(100) NOT NULL,
  `Department` varchar(100) NOT NULL,
  `Batch` varchar(100) NOT NULL,
  `Section` varchar(100) NOT NULL,
  `Semester` varchar(100) NOT NULL,
  `Year` varchar(10) NOT NULL,
  `DateOfIssue` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Student_ID` int(100) NOT NULL,
  `SName` varchar(100) NOT NULL,
  `Department` varchar(100) NOT NULL,
  `Batch` varchar(100) NOT NULL,
  `Section` varchar(100) NOT NULL,
  `Semester` varchar(100) NOT NULL,
  `Year` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`UserName`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
